package com.java1234;

import java.sql.Connection;

import com.java1234.dao.ArticleDao;
import com.java1234.entity.Article;
import com.java1234.util.CheckShareLinkEnableUtil;
import com.java1234.util.DbUtil;
import com.java1234.util.JedisUtil;

import redis.clients.jedis.Jedis;
	
public class Main {

	public static void main(String[] args) {
		DbUtil dbUtil=new DbUtil();
		Connection con=null;
		Integer nextId=null;
		ArticleDao articleDao=new ArticleDao();
		Jedis jedis=JedisUtil.getJedis();
		try{
			con=dbUtil.getCon();
			Article article=articleDao.getFirst(con);
			//System.out.println("check:"+article.getId());
			if(!CheckShareLinkEnableUtil.check(article.getDownload1())){
				System.out.println(article.getId()+"====无效");
				articleDao.invalid(con, article.getId());
				jedis.del("article_"+article.getId());
			}
			nextId=article.getId();
			Article nextArticle=articleDao.getNext(con, nextId);
			while(nextArticle!=null){
				Thread.sleep(1000);
				//System.out.println("check:"+nextArticle.getId());
				if(!CheckShareLinkEnableUtil.check(nextArticle.getDownload1())){
					System.out.println(nextArticle.getId()+"====无效");
					articleDao.invalid(con, nextArticle.getId());
					jedis.del("article_"+article.getId());
				}
				nextId=nextArticle.getId();
				nextArticle=articleDao.getNext(con, nextId);
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try {
				dbUtil.closeCon(con);
				jedis.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
