package com.java1234.util;

import com.sun.xml.internal.ws.message.MimeAttachmentSet;

import redis.clients.jedis.Jedis;

/**
 * Jedis工具类 操作redis
 * @author Administrator
 *
 */
public class JedisUtil {

	/**
	 * 获取jedis实例
	 * @return
	 */
	public static Jedis getJedis(){
        Jedis jedis=new Jedis(PropertiesUtil.getValue("redisIp"),Integer.parseInt(PropertiesUtil.getValue("redisPort"))); // 创建客户端 设置IP和端口
        jedis.auth(PropertiesUtil.getValue("redisAuth"));
        return jedis;
	}
	
	public static void main(String[] args) {
		Jedis jedis=JedisUtil.getJedis();
		jedis.del("article_100");
		jedis.close();
	}
}
