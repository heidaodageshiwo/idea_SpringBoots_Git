package com.java1234.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.java1234.entity.Article;

/**
 * 帖子Dao类
 * @author Administrator
 *
 */
public class ArticleDao {

	/**
	 * 获取第一条数据
	 * @param con
	 * @return
	 * @throws Exception
	 */
	public Article getFirst(Connection con)throws Exception{
		String sql="select * from t_article limit 0,1";
		Article article=null;
		PreparedStatement pstmt=con.prepareStatement(sql);
		ResultSet rs=pstmt.executeQuery();
		if(rs.next()){
			article=new Article();
			article.setId(rs.getInt("id"));
			article.setDownload1(rs.getString("download1"));
		}
		return article;
	}
	
	/**
	 * 获取下一条记录
	 * @param con
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public Article getNext(Connection con,Integer id)throws Exception{
		Article article=null;
		String sql="select * from t_article where id>? order by id asc limit 1";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		ResultSet rs=pstmt.executeQuery();
		if(rs.next()){
			article=new Article();
			article.setId(rs.getInt("id"));
			article.setDownload1(rs.getString("download1"));
		}
		return article;
	}
	
	/**
	 * 失效链接更新状态
	 * @param con
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public Integer invalid(Connection con,Integer id)throws Exception{
		String sql="update t_article set is_useful=false where id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		return pstmt.executeUpdate();
	}
}
