package com.java1234.entity;

/**
 * 资源实体
 * @author java1234 小锋 老师
 *
 */
public class Article{

	private Integer id; // 编号
	
	private String download1; // 百度云地址 下载地址1 用户地址
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDownload1() {
		return download1;
	}

	public void setDownload1(String download1) {
		this.download1 = download1;
	}


	
}
